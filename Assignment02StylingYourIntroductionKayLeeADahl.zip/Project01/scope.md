# Project Scope Statement

## Project Name
Personal Introduction Webpage

## Project Purpose
The purpose of this project is to apply the project management principle of scoping to a real, technical deliverable. By defining the boundaries, goals, and expectations of a personal webpage before writing any code, this project demonstrates how intentional planning improves clarity, efficiency, and decision-making during development.

This scope statement serves as a guide to prevent scope creep and to ensure that all technical work directly supports the learning objectives of the assignment.

## Description
This project consists of designing and building a simple, single-page personal website using semantic HTML. The webpage will introduce me by name, outline my academic and professional interests, and communicate my goals for this course and future career.

The site will prioritize clean structure, proper use of HTML elements, and readability. Visual styling and advanced functionality are intentionally excluded so the focus remains on structure, semantics, and planning rather than appearance.

## Desired Results
The project will be considered successful when the following outcomes are achieved:

* A valid `index.html` file that renders correctly in a modern web browser
* Proper use of semantic HTML elements to organize content logically
* Clear presentation of personal information, goals, and interests
* A completed `scope.md` document that clearly defines what is included and excluded
* Alignment between the scope statement and the final technical implementation

## Exclusions
To maintain focus and avoid unnecessary complexity, the following items are explicitly outside the scope of this project:

* CSS styling or visual design enhancements
* JavaScript or interactive features
* Responsive or mobile-first design considerations
* External libraries, frameworks, or templates
* Image, video, or multimedia content
* Deployment or hosting of the webpage online